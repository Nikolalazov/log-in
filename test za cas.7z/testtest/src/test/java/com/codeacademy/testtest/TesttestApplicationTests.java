package com.codeacademy.testtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesttestApplicationTests {

	@Test
	void contextLoads() {
	}

}
