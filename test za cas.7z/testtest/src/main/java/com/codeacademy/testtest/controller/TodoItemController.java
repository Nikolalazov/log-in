package com.codeacademy.testtest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.codeacademy.testtest.model.AppUser;
import com.codeacademy.testtest.model.TodoItem;
import com.codeacademy.testtest.service.TodoItemService;

@Controller
@SessionAttributes(names = "user")
public class TodoItemController {
	@Autowired
	TodoItemService todoService;
	
	@RequestMapping(path = "/list-todos", method = RequestMethod.GET)
	public String getTodos(Model model) {
		if (model.getAttribute("user") == null) {
			model.addAttribute("errorMessage", "You are not logged in!");
			return "redirect:/";
		} else {
			AppUser user = (AppUser)model.getAttribute("user");
			List<TodoItem> todos = todoService.getItems(user);
			model.addAttribute("todos", todos);
			return "list-todos";
		}
		
	}

}
