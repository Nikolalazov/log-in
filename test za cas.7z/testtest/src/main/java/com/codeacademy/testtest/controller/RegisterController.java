package com.codeacademy.testtest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.codeacademy.testtest.model.AppUser;
import com.codeacademy.testtest.service.AppUserService;


@Controller
@SessionAttributes(names = {"username", "user"})
public class RegisterController {
	
	@Autowired
	private AppUserService service;
	
	@RequestMapping(path = "/register", method = RequestMethod.GET)
	public String getRegisterForm(Model model) {
		return "register";
	}
	
	@RequestMapping(path = "/register", method = RequestMethod.POST)
	public String registerUser(@RequestBody String body, AppUser appUser, Model model) {
		appUser = service.saveUser(appUser);
		model.addAttribute("username", appUser.getUsername());
		model.addAttribute("user", appUser);
		return "redirect:/list-todos";
	}
	

}
