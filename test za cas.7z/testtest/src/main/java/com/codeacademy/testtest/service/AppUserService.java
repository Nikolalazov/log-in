package com.codeacademy.testtest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeacademy.testtest.model.AppUser;
import com.codeacademy.testtest.repository.AppUserRepository;

@Service
public class AppUserService {
	
	@Autowired
	private AppUserRepository repo;
	
	public AppUser saveUser(AppUser user) {
		repo.save(user);
		return user;
	}
	
	
	public List<AppUser> getUser(String username, String password) {
		return repo.findByUsernameAndPassword(username, password); 
	}
}
