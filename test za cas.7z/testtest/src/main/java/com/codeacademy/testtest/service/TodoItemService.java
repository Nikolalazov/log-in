package com.codeacademy.testtest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.codeacademy.testtest.model.AppUser;
import com.codeacademy.testtest.model.TodoItem;
import com.codeacademy.testtest.repository.TodoItemRepository;


@Service
public class TodoItemService {

	@Autowired
	TodoItemRepository tRepo;

	public List<TodoItem> getItems(AppUser user) {
		return tRepo.findByAppUser(user);
	}

}
