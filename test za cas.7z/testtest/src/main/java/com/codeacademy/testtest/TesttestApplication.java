package com.codeacademy.testtest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


import com.codeacademy.testtest.repository.AppUserRepository;
import com.codeacademy.testtest.repository.TodoItemRepository;


@SpringBootApplication

public class TesttestApplication {

	@Autowired
	private AppUserRepository userRepo;
	@Autowired
	private TodoItemRepository todoRepo;
	
	public static void main(String[] args) {
		SpringApplication.run(TesttestApplication.class, args);
	}

}
