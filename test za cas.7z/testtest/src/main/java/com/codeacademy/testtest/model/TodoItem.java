package com.codeacademy.testtest.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.data.annotation.Version;

@Entity
@Table(name = "TODO_ITEM")
public class TodoItem {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long id;
	@Version
	private Long version;
	private String userce;
	private String description;
	private Date targetDate;
	private boolean finished;

	@ManyToOne(fetch = FetchType.EAGER, optional = false)
	@JoinColumn(name = "APP_USER_ID")
	private AppUser appUser;

	public TodoItem() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getVersion() {
		return this.version;
	}

	public void setVersion(Long version) {
		this.version = version;
	}

	public String getUserce() {
		return userce;
	}

	public void setUserce(String userce) {
		this.userce = userce;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

	public boolean isFinished() {
		return finished;
	}

	public void setFinished(boolean finished) {
		this.finished = finished;
	}

	public AppUser getAppUser() {
		return appUser;
	}

	public void setAppUser(AppUser appUser) {
		this.appUser = appUser;
	}

	@Override
	public String toString() {
		return "TodoItem [id=" + id + ", version=" + version + ", userce=" + userce + ", description=" + description
				+ ", targetDate=" + targetDate + ", finished=" + finished + "]";
	}

}