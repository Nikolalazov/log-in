package com.codeacademy.testtest.repository;

import java.awt.print.Pageable;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.codeacademy.testtest.model.AppUser;
import com.codeacademy.testtest.model.TodoItem;

import net.bytebuddy.asm.Advice.OffsetMapping.Sort;

/**
 * Lets do derived quesris 
 * QUERY_PATTERN = "find|read|get|query|stream";
 * DELETE_PATTERN = "delete|remove";
 */
public interface TodoItemRepository extends JpaRepository<TodoItem, Long>{
	
	public List<TodoItem> findByDescription(String dscr);
	public List<TodoItem> findByAppUser(AppUser user);
	public List<TodoItem> findByTargetDate(String month);

	//complex  query for nested entity graph 
	public List<TodoItem> findByAppUser_Id(Long id);
	public List<TodoItem> findByAppUser_Email(String email);
	
	
}