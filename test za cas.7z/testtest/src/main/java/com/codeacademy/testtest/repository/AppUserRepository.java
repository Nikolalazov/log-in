package com.codeacademy.testtest.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.codeacademy.testtest.model.AppUser;



@Repository
public interface AppUserRepository extends JpaRepository<AppUser, Long> {
	
	List<AppUser> findByUsernameAndPassword(String username, String password);

}
